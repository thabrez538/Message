package com.example.register.machinestatus;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.example.register.machine.Machine;

@Entity
@Table
public class MachineStatus {
	@Id
	int status_id;
	
	@ManyToOne
	@JoinColumn(name="id")
	private Machine machine;
	
	String status;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date timestamp;

	

	public MachineStatus(int status_id, Machine machine, String status, Date timestamp) {
		super();
		this.status_id = status_id;
		this.machine = machine;
		this.status = status;
		this.timestamp = timestamp;
	}
	
	


	public int getStatus_id() {
		return status_id;
	}




	public void setStatus_id(int status_id) {
		this.status_id = status_id;
	}




	public Machine getMachine() {
		return machine;
	}




	public void setMachine(Machine machine) {
		this.machine = machine;
	}




	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}




	public Date getTimestamp() {
		return timestamp;
	}




	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}




	public MachineStatus() {
		
	}
}
