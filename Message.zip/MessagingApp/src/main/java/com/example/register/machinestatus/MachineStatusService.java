package com.example.register.machinestatus;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.register.MachineStatusNotFoundException.MachineStatusNotFoundException;

@Service
public class MachineStatusService {
	
	private MachineStatusRepository statusRepository;
	
	@Autowired
	public MachineStatusService(MachineStatusRepository statusRepository) {
		this.statusRepository=statusRepository;
	}
	
	public List<MachineStatus> getAllMachineStatus(){
		return statusRepository.findAll();
	}
	public MachineStatus getStatusById(int id) {
		return statusRepository.findById(id).orElse(null);
	}
	
	public MachineStatus addMachineStatus(MachineStatus machinestatus) {
		return statusRepository.save(machinestatus);
	}
	
	@Transactional
	public MachineStatus updatedMachineStatus(int id,String newstatus) {
		Optional<MachineStatus> optionalMachineStatus=statusRepository.findById(id);
		if(!optionalMachineStatus.isPresent()) {
			throw new MachineStatusNotFoundException("Not found");
		}
			MachineStatus machinestatus=optionalMachineStatus.get();
			machinestatus.setStatus(newstatus);
			machinestatus.setTimestamp(new Date());
			
			return statusRepository.save(machinestatus);
			
		}
		
	
}

