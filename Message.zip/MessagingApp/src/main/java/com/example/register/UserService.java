package com.example.register;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class UserService {
	    @Autowired
	    private UserRepository userRepository;

	    public User createUser(User user) {
	        // You might want to encode the password before saving it
	        return userRepository.save(user);
	    }

	    public User getUserByUsername(String username) {
	        return userRepository.findByUsername(username);
	    }
}
