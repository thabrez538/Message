package com.example.register.machinestatus;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/machinestatus")
public class MachineStatusController {
	private MachineStatusService machinestatusservice;
	
	@Autowired
	public MachineStatusController(MachineStatusService machinestatusservice) {
		this.machinestatusservice=machinestatusservice;
	}
	
	@GetMapping
	public List<MachineStatus> getAllMachinestatus(){
		return machinestatusservice.getAllMachineStatus();
	}
	
	@GetMapping("/{id}")
	public MachineStatus getStatusById(@PathVariable int id) {
		return machinestatusservice.getStatusById(id);
	}
	
	@PostMapping("/add")
	public MachineStatus addMachineStatus(@RequestBody MachineStatus machineStatus) {
		return machinestatusservice.addMachineStatus(machineStatus);
	}
	
	@PutMapping("/update/{id}")
	public MachineStatus updateMachineStatus(@PathVariable int id,String status) {
		return machinestatusservice.updatedMachineStatus(id,status);
	}
}
