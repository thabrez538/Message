package com.example.register.machine;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/machines")
public class MachineController {
	private MachineRepository machineRepo;
	
	@Autowired
	public MachineController(MachineRepository machineRepo) {
		this.machineRepo=machineRepo;
	}
	
	@PostMapping("/register")
	public ResponseEntity<Machine> registermachine(@RequestBody Machine machine){
		Machine createdMachine=machineRepo.save(machine);
		return new ResponseEntity<>(createdMachine,HttpStatus.CREATED);
	}
	
	@GetMapping
	public List<Machine> getAllMachines(){
		return machineRepo.findAll();
	}
}
