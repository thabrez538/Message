package com.example.register;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	Logger l=LoggerFactory.getLogger(UserController.class);
	@Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        // You might want to encode the password before saving it
        User createdUser = userService.createUser(user);
        l.info("User created");
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }
    
   @GetMapping("/{username}")
   public User getAllUsers(@PathVariable String username) {
	   return userService.getUserByUsername(username);
   }
}
